# Current results summary (from existing CSVs) + improvement directions

This document summarizes the *existing* MarketSim results included in this package (no new numbers are fabricated).
See `existing_results/csv/*.csv` and `existing_results/figures/*.png`.

## What the existing run already demonstrates
- A strictly-causal evidence-driven mechanism can improve tracking performance vs standard Hedge / FixedShare baselines on nonstationary families.
- The benchmark is fully reproducible and includes a DP switching oracle (S=10) to compute DynRegret.

## Included metrics
- `hard_suite_results.csv`: DynRegret mean/std per (Family, Method)
- `paired_ttests.csv`: paired tests vs baselines (episode-level)
- `recovery_alignment.csv`: recovery time & alignment diagnostics
- `scaling_results.csv`: scaling with (T,S) and fit against theoretical terms
- `runtime_benchmark.csv`: per-step runtime components
- Figures: average dyn-regret bar chart, scaling plot, tracking episode, rho episode, weights heatmap

## Best-paper upgrade path (Transformer becomes the *core model*)
Keep the outer algorithm (Fixed-Share) unchanged for proofs and diagnostics. Replace only the evidence-to-update mapping:
- Replace hand-crafted or shallow evidence scoring with an Evidence Transformer `G_θ`.
- Inputs: strictly-causal evidence token sequence (multi-scale backtests).
- Outputs: surrogate losses `\tildeℓ_t` and adaptive share hazard `ρ_t`, clipped.

### Experiments needed for a Transformer-core paper
1) Backbone ablation (same interface, same evaluation):
   - Causal Transformer (KV cache)
   - Transformer-XL (segment recurrence)
   - Patch Transformer (PatchTST-style)
   - iTransformer-style (expert-dimension-as-tokens)
   - Efficient attention (Performer/Linformer) for runtime Pareto
2) Mechanism ablation:
   - no evidence (use only current losses)
   - no adaptive share (ρ fixed)
   - no surrogate (use true losses)
   - robust vs non-robust evidence under heavy tails
3) Pareto frontier: DynRegret vs runtime (vary L, K, attention variant)
4) Statistical rigor:
   - bootstrap CIs
   - Holm-Bonferroni for multiple comparisons
5) Diagnosability figures:
   - weights vs regimes alignment
   - ρ_t vs change-point/drift proxy
   - recovery time distributions
