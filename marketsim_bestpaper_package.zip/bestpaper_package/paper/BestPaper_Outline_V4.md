# Evidence-Driven Transformer Expert Tracking (EDT-FS)
## Best-paper Style Paper Outline (V4)

> 目标：非平稳时序在线预测，竞争至多 S 次切换的 switching-oracle，并在严格因果(no-leakage)约束下实现“可定义-可证明-可复核”的闭环。
> 核心范式：**Strictly-causal post-validation evidence** → **Transformer 生成更新信号(\tilde\ell, \rho)** → **Fixed-Share Hedge 可证明 tracking 外壳**。

---

## 0. Abstract
- 问题：nonstationary online forecasting；以 \(\Pi_S\) switching comparator 定义 \(\mathrm{DynRegret}_S\)。
- 方法：定义严格因果的 post-validation evidence operator；用 **Streaming Causal Transformer**（及变体）映射证据到 surrogate losses \(\tilde\ell_{t,1:K}\) 与 share hazard \(\rho_t\)；随后用 fixed-share Hedge 更新权重。
- 理论：给出 time-varying \(\rho_t\) 的 tracking 上界 + surrogate-to-true transfer；将学习复杂性压缩为 \(\sum_t\varepsilon_t\) 误差通道，并进一步分解为 bt/net/ns。
- 基准与结果：MarketSim + DP switching oracle（可复核闭环）；展示 dyn-regret、oracle gap、recovery、diagnosability、scaling 与 runtime Pareto。

---

## 1. Introduction（含一张总览图）
1. Nonstationarity + heavy-tails + diagnosability + compute 的矛盾  
2. 现有方法缺口：static comparator；黑箱 gating 不可证；vanilla Hedge 在 heavy-tail/依赖下不稳  
3. 核心思想：Validation-as-Evidence + Restricted Update（Transformer 仅输出更新信号；权重递推固定可证）  
4. Contributions：Theorem / Figure / Benchmark 对齐（每条都可复核）

---

## 2. Problem Setup and Comparator
- 在线协议与过滤族 \(\mathcal F_t\)（预测基于 \(\mathcal F_{t-1}, x_t\)）  
- 专家库 \(\{f_k\}_{k=1}^K\)，混合预测与损失上界（凸损失/Jensen/log-loss）  
- Switching comparator：\(\Pi_S\) 与 \(L_T^{sw}(S)\)，动态遗憾 \(\mathrm{DynRegret}_S\)

---

## 3. Strictly-Causal Post-Validation Evidence Operator
### 3.1 定义 \(\mathsf{Val}_t\)
输入：窗口 \(\mathcal W_t\)，forward-chaining split，专家预测缓存/回放方式；输出：每 expert 的验证损失统计与全局统计。  

### 3.2 Forward-chaining split（写死以杜绝 leakage）
cutpoint \(c_t^{(j)}\in[t-N+1,t-V]\)  
训练段 \([t-N+1,c_t^{(j)}]\)，验证段 \([c_t^{(j)}+1,c_t^{(j)}+V]\)

### 3.3 命题：Strict causality（无泄漏）
证明每个 evidence token \(z_t\) 与 \(\widehat L_{t,k}^{(j)}\) 都是 \(\mathcal F_t\)-可测且验证预测不使用验证段未来。

### 3.4 Robust evidence（heavy-tail / dependence）
使用 Huber / trimmed mean / MoM；以 \(V_{eff}\) 表达相关性导致的有效样本数。

### 3.5 Tokenization（最小充分 + 可复现）
专家 token：多尺度块均值/方差/分位数/稳定性  
全局 token：分歧度、熵、漂移 proxy、波动 proxy  
给出逐维公式与 clip 规则。

---

## 4. Evidence Transformer Family（核心模型）
### 4.1 接口（不破坏理论）
输入：最近 \(L\) 步 token 序列 \(Z_{t-L+1:t}\)（严格因果）  
输出：\((\tilde\ell_{t,1:K}, \rho_t)\)，并 clip：\(\tilde\ell\in[0,1],\ \rho_t\in[\rho_{min},\rho_{max}]\)

### 4.2 主干：Streaming Causal Transformer（KV cache）
encoder-only + causal mask；在线推理用 KV cache。  
输出头：per-expert head（\(K\) 维）+ global hazard head（\(1\) 维）。

### 4.3 变体族（统一评测接口）
- Transformer-XL：segment recurrence，长记忆  
- Patch Transformer（PatchTST 思路）：patch 压缩以降低 \(L\) 带来的计算  
- iTransformer（inverted tokens）：把“专家维/通道维”当 token，建模专家替代/互补结构  
- Efficient attention：FlashAttention / Performer / Linformer / Longformer（做 regret-runtime Pareto）  
- （可选）SSM backbone（如 Mamba）：同接口替换注意力，线性扩展

---

## 5. Algorithm: EDT-FS（Algorithm 1）
1. 观察 \(x_t\)，专家产生预测 \(\hat y_{t,k}\)  
2. 观察 \(y_t\)，得到 \(\ell_{t,k}\) 并更新 evidence operator（严格因果）  
3. Transformer：\((\tilde\ell_t,\rho_t)=G_\theta(z_{\le t})\)  
4. Fixed-share 更新：\(w_{t+1}=(1-\rho_t)\mathrm{Hedge}(w_t,\tilde\ell_t)+\rho_t\mathbf1/K\)

复杂度：证据计算 + Transformer 推理 + O(K) 权重更新。

---

## 6. Learning (Algorithm 2)
- Teacher：DP switching oracle 提供 expert label 与切换(hazard)标签  
- 两阶段：蒸馏对齐（CE+BCE）→ regret-aligned fine-tuning（直接优化 dyn-regret / oracle gap）  
- 稳定性：clip、温度标定、早停；记录 \(\sum_t\varepsilon_t\) 作为可诊断指标。

---

## 7. Theory（主定理前置）
- Lemma 1：time-varying fixed-share surrogate tracking bound  
- Lemma 2：surrogate-to-true transfer（误差通道 \(2\sum_t\varepsilon_t\)）  
- Theorem 1：\(\mathrm{DynRegret}_S\) 上界 = tracking 项 + switching prior 项 + 学习误差项  
- Proposition：\(\varepsilon_t=\varepsilon_t^{bt}+\varepsilon_t^{net}+\varepsilon_t^{ns}\)，并给出可实验对齐 knob。

---

## 8. Benchmark: MarketSim + DP Switching Oracle
- Generator API + 标注字段（regime、变点）  
- Families（ultra_stable / burst_switch / multi_burst / heavy_tail）  
- DP oracle：\(O(TKS)\) recursion；评测协议可复核。

---

## 9. Experiments（Best-paper 证据链）
- 主表：DynRegret 与 oracle gap（mean±CI），并做 paired test + bootstrap  
- Backbone 消融：Causal / XL / Patch / iTransformer / linear-attn  
- 机制必要性：去证据、去 share、只学 \(\rho\)、只学 surrogate、稳健统计对照  
- Diagnosability：权重-状态对齐、\(\rho_t\)-drift 对齐、recovery time  
- Scaling：扫 \((T,K,S,N,J,V,L)\) 验证量纲与 trade-off  
- Runtime：regret-runtime Pareto（工程可部署）

---

## Appendix
- Proofs；dependence/heavy-tail concentration；DP oracle 细节；token 维度表；复现 checklist（seed、超参、wall-clock、硬件）。
