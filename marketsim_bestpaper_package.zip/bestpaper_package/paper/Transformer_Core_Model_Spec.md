# Transformer-core model spec (EDT-FS)

Goal: make Transformer (and variants) the *core model* while keeping the provable Fixed-Share outer loop.

## Interface (must remain fixed for theory)
Given strictly-causal evidence tokens z_{≤t} (optionally last L steps):
- Output surrogate losses: \tildeℓ_{t,1:K} ∈ [0,1]
- Output adaptive share: ρ_t ∈ [ρ_min, ρ_max] ⊂ (0,1)

Then update:
  \bar w_{t+1,k} ∝ w_{t,k} exp(-η \tildeℓ_{t,k})
  w_{t+1} = (1-ρ_t) \bar w_{t+1} + ρ_t · 1/K

## Transformer family (drop-in backbones)
- Streaming causal Transformer (encoder-only, causal mask, KV cache)
- Transformer-XL: segment recurrence for longer memory
- Patch Transformer: patch tokens to reduce L
- iTransformer style: treat experts as tokens; model expert substitution/interaction
- Efficient attention: Performer/Linformer; FlashAttention for speed (exact attention)

## Training (best-practice)
- Distill from DP switching oracle:
  - expert label y_t = π*_{t+1}
  - hazard label s_t = 1[π*_{t+1} != π*_{t}]
- Stage-1: supervised CE + BCE to stabilize
- Stage-2: regret-aligned fine-tuning (optimize DynRegret/oracle gap) if autograd is available

## What to report
- Main DynRegret table on the hard suite + CI
- Backbone & mechanism ablations
- Pareto curve (runtime vs DynRegret)
- Diagnosability plots (weights, ρ_t vs regimes/drift)
